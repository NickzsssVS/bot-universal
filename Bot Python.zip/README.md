# Bot de Pagamento Simulado

Este é um bot do Discord que simula um sistema de pagamento com comandos básicos de banco.

## Configuração

1. Instale as dependências:
```bash
pip install -r requirements.txt
```

2. Configure o token do bot:
   - Abra o arquivo `main.py`
   - Substitua "SEU_TOKEN_AQUI" pelo token do seu bot do Discord

3. Execute o bot:
```bash
python main.py
```

## Comandos Disponíveis

- `.criarconta` - Cria uma conta bancária com saldo inicial aleatório
- `.saldo` - Mostra seu saldo atual
- `.depositar valor` - Adiciona dinheiro à sua conta
- `.transferir @usuario valor` - Transfere dinheiro para outro usuário
- `.extrato` - Mostra suas últimas 5 transações

## Características

- Sistema totalmente simulado (sem API real)
- Interface bonita com embeds
- Tratamento de erros
- Verificações de segurança
- Registro de transações
- Formatação em reais (R$)
- Datas no formato brasileiro

## Observações

- Os dados são armazenados em memória e serão perdidos quando o bot for reiniciado
- Todos os valores são em reais (R$)
- O sistema é apenas para testes e simulação 